package com.example.dpcmgr4v1.dataAccesLayer;

public class ConsultantMapper {
    public com.example.dpcmgr4v1.model.classes.Consultant login(int id, String consulentName, String password) {

        return null;
    }
}
