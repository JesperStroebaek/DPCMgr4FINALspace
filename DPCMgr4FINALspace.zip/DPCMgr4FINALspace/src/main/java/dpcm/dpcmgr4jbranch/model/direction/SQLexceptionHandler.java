package com.example.dpcmgr4v1.model.direction;



public class SQLexceptionHandler extends Exception
{
    public SQLexceptionHandler(String msg){
        super(msg);
    }
}
