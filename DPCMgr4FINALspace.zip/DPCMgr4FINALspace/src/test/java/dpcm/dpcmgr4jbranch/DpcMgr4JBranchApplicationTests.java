package dpcm.dpcmgr4jbranch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DpcMgr4JBranchApplicationTests {

    @Test
    void contextLoads() {
    }

}
