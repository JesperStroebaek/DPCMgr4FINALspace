package dpcm.dpcmgr4jbranch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DpcMgr4JBranchApplication {

    public static void main(String[] args) {
        SpringApplication.run(DpcMgr4JBranchApplication.class, args);
    }

}
